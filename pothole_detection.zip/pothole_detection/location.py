import random

def get_current_location():
    lat = random.uniform(21.20, 21.35)
    lon = random.uniform(81.60, 81.75)
    return lat, lon
